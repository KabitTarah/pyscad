from abc import ABC, abstractmethod
from dataclasses import dataclass
from openscad import PyOpenSCAD
from pythonscad import cube

from pyscad.sign_gen.parameters import BaseParameters

class SignShape(ABC):
    """
    Base class for shape of sign
    """
    def __init__(
            self,
            params: BaseParameters = BaseParameters()
    ):
        self.params = params

    @abstractmethod
    def build_shape(self) -> PyOpenSCAD:
        """
        Returns a pythonscad shape containing the base sign, centered
        """
        raise NotImplementedError()

class SignRectangle(SignShape):
    """
    Rectangular Sign
    """
    def build_shape(self) -> PyOpenSCAD:
        base = cube([
            self.params.base_width_mm,
            self.params.base_height_mm,
            self.params.base_thickness_mm,
        ])
        border_1 = cube([
            self.params.base_width_mm - 2 * self.params.border_gap_mm,
            self.params.base_height_mm - 2 * self.params.border_gap_mm,
            self.params.border_height_mm,
        ]).translate([
            self.params.border_gap_mm,
            self.params.border_gap_mm,
            self.params.base_thickness_mm,
        ])
        border_2 = cube([
            self.params.base_width_mm - 2 * self.params.border_gap_mm - 2 * self.params.border_thickness_mm,
            self.params.base_height_mm - 2 * self.params.border_gap_mm - 2 * self.params.border_thickness_mm,
            self.params.border_height_mm,
        ]).translate([
            self.params.border_gap_mm + self.params.border_thickness_mm,
            self.params.border_gap_mm + self.params.border_thickness_mm,
            self.params.base_thickness_mm,
        ])
        border = border_1.difference(border_2)

        return base.union(border)
