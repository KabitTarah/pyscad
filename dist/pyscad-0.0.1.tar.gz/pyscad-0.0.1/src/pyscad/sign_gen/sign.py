from pyscad.sign_gen.sign_shapes import SignRectangle
from pythonscad import show

rect = SignRectangle()

show(rect.build_shape())